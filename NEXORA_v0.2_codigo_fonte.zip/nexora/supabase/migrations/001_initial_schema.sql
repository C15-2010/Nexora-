-- NEXORA initial schema — execute no SQL Editor do Supabase.
-- Segurança: todas as tabelas de negócio são isoladas pelo business_id e RLS.

create extension if not exists pgcrypto;

create table if not exists public.businesses (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null default 'Meu negócio',
  segment text not null default 'Comércio',
  created_at timestamptz not null default now()
);

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  name text not null,
  sku text,
  category text,
  price numeric(12,2) not null default 0 check (price >= 0),
  cost numeric(12,2) not null default 0 check (cost >= 0),
  stock integer not null default 0 check (stock >= 0),
  min_stock integer not null default 0 check (min_stock >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  name text not null,
  phone text,
  email text,
  created_at timestamptz not null default now()
);

create table if not exists public.sales (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  customer_id uuid references public.customers(id) on delete set null,
  customer_name text,
  description text,
  quantity integer not null default 1 check (quantity > 0),
  total numeric(12,2) not null check (total >= 0),
  sold_at date not null default current_date,
  created_at timestamptz not null default now()
);

create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references public.businesses(id) on delete cascade,
  description text not null,
  category text,
  amount numeric(12,2) not null check (amount > 0),
  spent_at date not null default current_date,
  created_at timestamptz not null default now()
);

create index if not exists products_business_idx on public.products(business_id);
create index if not exists sales_business_date_idx on public.sales(business_id, sold_at desc);
create index if not exists customers_business_idx on public.customers(business_id);
create index if not exists expenses_business_date_idx on public.expenses(business_id, spent_at desc);

alter table public.businesses enable row level security;
alter table public.products enable row level security;
alter table public.customers enable row level security;
alter table public.sales enable row level security;
alter table public.expenses enable row level security;

-- O proprietário só pode acessar o próprio negócio.
drop policy if exists "owner manages own business" on public.businesses;
create policy "owner manages own business" on public.businesses
for all to authenticated
using (owner_id = auth.uid())
with check (owner_id = auth.uid());

-- Cada registro só é acessível quando pertence a um negócio do usuário autenticado.
do $$
declare t text;
begin
  foreach t in array array['products','customers','sales','expenses']
  loop
    execute format('drop policy if exists "owner manages business %1$s" on public.%1$I', t);
    execute format(
      'create policy "owner manages business %1$s" on public.%1$I for all to authenticated using (exists (select 1 from public.businesses b where b.id = business_id and b.owner_id = auth.uid())) with check (exists (select 1 from public.businesses b where b.id = business_id and b.owner_id = auth.uid()))',
      t
    );
  end loop;
end $$;

-- Impede que referências de venda apontem para produto/cliente de outro negócio.
create or replace function public.validate_sale_relations()
returns trigger language plpgsql security invoker set search_path = public
as $$
begin
  if new.product_id is not null and not exists (
    select 1 from public.products p where p.id = new.product_id and p.business_id = new.business_id
  ) then raise exception 'Produto inválido para este negócio'; end if;
  if new.customer_id is not null and not exists (
    select 1 from public.customers c where c.id = new.customer_id and c.business_id = new.business_id
  ) then raise exception 'Cliente inválido para este negócio'; end if;
  return new;
end;
$$;

drop trigger if exists sales_validate_relations on public.sales;
create trigger sales_validate_relations before insert or update on public.sales
for each row execute function public.validate_sale_relations();

-- NOTA: esta versão registra a venda sem baixar estoque automaticamente.
-- Isso evita inconsistências até a implementação de um fluxo transacional de venda.
