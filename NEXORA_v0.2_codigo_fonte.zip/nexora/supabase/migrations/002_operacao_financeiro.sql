-- NEXORA v0.2: vendas com forma de pagamento, custo histórico e baixa automática de estoque.
-- Execute DEPOIS da migration 001 no SQL Editor do Supabase.

alter table public.sales
  add column if not exists payment_method text not null default 'Não informado',
  add column if not exists subtotal numeric(12,2) not null default 0 check (subtotal >= 0),
  add column if not exists discount numeric(12,2) not null default 0 check (discount >= 0),
  add column if not exists unit_cost numeric(12,2) not null default 0 check (unit_cost >= 0);

-- Mantém o subtotal dos registros antigos e registra o custo vigente nas novas vendas.
update public.sales set subtotal = total where subtotal = 0;

-- Registra o custo vigente no momento da venda e valida os vínculos.
create or replace function public.prepare_nexora_sale()
returns trigger language plpgsql security invoker set search_path = public
as $$
declare product_cost numeric(12,2);
begin
  if new.product_id is not null then
    select cost into product_cost from public.products
    where id = new.product_id and business_id = new.business_id;
    if not found then raise exception 'Produto inválido para este negócio.'; end if;
    if tg_op = 'INSERT' then new.unit_cost := coalesce(product_cost, 0); end if;
  end if;
  if new.discount > new.subtotal then raise exception 'O desconto não pode ser maior que o subtotal.'; end if;
  new.total := greatest(new.subtotal - new.discount, 0);
  if new.customer_id is not null and not exists (
    select 1 from public.customers c where c.id = new.customer_id and c.business_id = new.business_id
  ) then raise exception 'Cliente inválido para este negócio.'; end if;
  return new;
end;
$$;

drop trigger if exists sales_prepare_nexora on public.sales;
create trigger sales_prepare_nexora before insert or update on public.sales
for each row execute function public.prepare_nexora_sale();

-- Atualiza estoque dentro da mesma transação da venda. Se faltar estoque, cancela a venda.
create or replace function public.sync_nexora_sale_stock()
returns trigger language plpgsql security invoker set search_path = public
as $$
declare affected integer;
begin
  if tg_op = 'INSERT' then
    if new.product_id is not null then
      update public.products set stock = stock - new.quantity
      where id = new.product_id and business_id = new.business_id and stock >= new.quantity;
      get diagnostics affected = row_count;
      if affected = 0 then raise exception 'Estoque insuficiente. Atualize a quantidade antes de registrar a venda.'; end if;
    end if;
    return new;
  elsif tg_op = 'DELETE' then
    if old.product_id is not null then
      update public.products set stock = stock + old.quantity
      where id = old.product_id and business_id = old.business_id;
    end if;
    return old;
  else
    if old.product_id is not null then
      update public.products set stock = stock + old.quantity
      where id = old.product_id and business_id = old.business_id;
    end if;
    if new.product_id is not null then
      update public.products set stock = stock - new.quantity
      where id = new.product_id and business_id = new.business_id and stock >= new.quantity;
      get diagnostics affected = row_count;
      if affected = 0 then raise exception 'Estoque insuficiente para atualizar esta venda.'; end if;
    end if;
    return new;
  end if;
end;
$$;

drop trigger if exists sales_sync_nexora_stock on public.sales;
create trigger sales_sync_nexora_stock after insert or update or delete on public.sales
for each row execute function public.sync_nexora_sale_stock();

create index if not exists sales_business_payment_idx on public.sales(business_id, payment_method);
